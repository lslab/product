<?php
set_time_limit(30);

define('ROOT', dirname(__FILE__));

ini_set('include_path', ROOT . '/libs/PEAR');

include_once(ROOT . '/config.inc.php');
include_once(ROOT . '/libs/common.php');
include_once(ROOT . '/libs/sms2.php');
include_once(ROOT . '/db.class.php');
include_once(ROOT . '/reply.php');

include_once('HTTP/myClient.php');
$http = new myHttpClient();
$http->setMaxRedirects(0);

$con = $http->getHTML("http://www.im286.com/forumdisplay.php?fid=41");
file_put_contents(ROOT.'/286.html',$con);

preg_match_all('/thread-(\d+)-1-1/',$con,$artid);
$tids = array_unique($artid[1]);
pp($tids);
$rs = $db->findAll('tasks', null, "site='im286'");
$oldtids = array();
foreach ((array)$rs as $v)
{
	$oldtids[] = $v['id'];
}

foreach ($tids as $tid) {
    if (!in_array($tid, $oldtids)) {
    	$topicurl="http://www.im286.com/thread-$tid-1-1.html";
        $con = $http->getHTML($topicurl);
		preg_match('/<title>(.*?) - �����ֽ�������/', $con, $arTitle);
		pp($arTitle);
		$title=$arTitle[1];
		$title=strip_tags($title);
		$title=trim($title);
	
		$isSend=true;
		foreach ($limitKey as $limit) {
			if (strpos(strtolower($title),strtolower($limit))!==false) {
        		$isSend=false;
        	}
        }

        $isSend && sendsms2('[��]'.$title);

		echo $arTitle[1]."\n";/////////////////////////////
        $db->create('tasks', array('id' => $tid, 'site' => 'im286'));
        
        $reply=false;
        foreach ($replyKey as $key) {
        	if (strpos(strtolower($title),strtolower($key))!==false) {
        		$reply=true;
        	}
        }
        if ($isSend && $reply) {
        	reply('http://www.im286.com',$topicurl,'������������ϵ�ҡ�QQ��107710715');
        }
    }
}



