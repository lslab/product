<?php

require_once 'HTTP/Client.php';

class myHttpClient extends HTTP_Client {
	function getBody()
	{
		$response = $this->currentResponse();
		return $response['body'];
	}
	
	function getResponse()
	{
		return $this->currentResponse();
	}

	function getHtml($url) {
		$this->get($url);
		return $this->getBody();
	}
}

?>