<?php

function sget($url,$conall=null)
{
	$purl = parse_url($url);
	$host = $purl['host'];
	$path = $purl['path'];
    if (isset($purl['query']))
		$path.='?'.$purl['query'];
	$fp = fsockopen($host, 80, $errno, $errstr, 10);
	if (!$fp) {
	    echo $errno.$errstr;
		return false;
	} else {

	$out = "GET $path HTTP/1.1\r\n";
	$out.= "Accept: */*\r\n";
	$out.= "Accept-Language: zh-cn\r\n";
//	$out.= "UA-CPU: x86\r\n";
//	$out.= "Accept-Encoding: gzip, deflate\r\n";
	$out.= "Referer: http://$host\r\n";
	//$out.= "If-Modified-Since: Wed, 10 Aug 2005 09:52:06 GMT\r\n";
	//$out.= "If-None-Match: \"56c8152b919dc51:ddd\"\r\n";
	$out.= "User-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; SV1; .NET CLR 1.1.4322)\r\n";
	$out.= "Host: $host\r\n";
	$out.= "Connection: Close\r\n";
	//$out.= "Cookie: rtime=7; ltime=1124891230804; cnadmin=true\r\n";
	$out.="\r\n";

	    fwrite($fp, $out);
	    while (!feof($fp)) {
	        $con.= fgets($fp, 1024);
	    }
	    fclose($fp);
	}

    if ($conall==null)
    {
		$tmp = explode("\r\n\r\n",$con,2);
		$con = $tmp[1];
    }
	return $con;
}

function pp($v,$d=null)
{
        echo '<pre>';
        print_r($v);
        echo '</pre>';
        $d==null or die;
}


?>