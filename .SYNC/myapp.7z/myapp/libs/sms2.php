<?php
//error_reporting(E_ALL);
//header("Cache-Control: no-cache");
//ob_implicit_flush();

function sendsms2($s) {
	//ini_set('include_path', dirname(__FILE__) . '/PEAR');
	//include_once('HTTP/Client.php');
	global $http;
	//login
	//$http = new HTTP_Client();
	$posturl = "http://school.jxllt.com/login_action.asp";
	$post = array(
	    'txt_userid' => '420064',
	    'txt_passwd' => '12345678',
	    'rad_usertype' => 'B'
	);
	$http->post($posturl,$post);

	//send
	$posturl = "http://school.jxllt.com/teacher/schnotice_action.asp";
	$data = array();
	$data['sel_group'] = '11524';
	$data['rcvlist'] = '420064|�˽�';
	$data['txta_memo'] = $s;
	$data['remain2'] = '20';
	$data['remain1'] = '90';
	$data['msgtime'] = '';
	$data['SEND'] = '����';
	$http->post($posturl,$data);
	$resp = $http->currentResponse();
	//pp($resp,1);
}
