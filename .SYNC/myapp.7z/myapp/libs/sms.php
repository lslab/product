<?php

//��½JXLLTϵͳ
function loginsms()
{
    $fp = fsockopen("school.jxllt.com", 80, $errno, $errstr, 30);
    if (!$fp) {
        return false;
    } else {
        $out = "POST /login_action.asp HTTP/1.1\r\n";
        $out.= "Accept: image/gif, image/x-xbitmap, image/jpeg, image/pjpeg, application/x-shockwave-flash, application/msword, application/vnd.ms-excel, application/vnd.ms-powerpoint, */*\r\n";
        $out.= "Referer: http://www.jxllt.com/index.htm\r\n";
        $out.= "Accept-Language: zh-cn\r\n";
        $out.= "Content-Type: application/x-www-form-urlencoded\r\n";
        $out.= "Accept-Encoding: gzip, deflate\r\n";
        $out.= "User-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Maxthon; .NET CLR 1.1.4322)\r\n";
        $out.= "Host: school.jxllt.com\r\n";
        $out.= "Content-Length: 72\r\n";
        $out.= "Connection: Close\r\n";
        $out.= "Cache-Control: no-cache\r\n";
        $out.= "\r\n";
        $out.= "txt_userid=420064&txt_passwd=12345678&rad_usertype=B&Submit=%B5%C7%C2%BD";
        fwrite($fp, $out);
        while (!feof($fp)) {
            $con.= fgets($fp, 1024);
        }
        fclose($fp);
    }

    $tmp = explode("\r\n\r\n",$con,2);
    preg_match("/Set-Cookie:(.*?)\n/i",$con,$ar);
    $cookie = trim($ar[1]);

    return $cookie;
}//end loginsms

//���Ͷ���
function sendsms($tomobile,$msg)
{
    if(!$cookie=loginsms()) return false;
    $fp = fsockopen("school.jxllt.com", 80, $errno, $errstr, 30);
    if (!$fp) {
        return false;
    } else {
        $postmsg = "tmobile=$tomobile&grouptype=teacher&groupmember=051251309080&txta_memo=".urlencode($msg)."&viewcon=&remain2=5&remain1=205&submit=%B7%A2%CB%CD";
        $len = strlen($postmsg);

        $out = "POST /teacher/perwritesms_action.asp HTTP/1.1\r\n";
        $out.= "Accept: image/gif, image/x-xbitmap, image/jpeg, image/pjpeg, application/x-shockwave-flash, application/msword, application/vnd.ms-excel, application/vnd.ms-powerpoint, */*\r\n";
        $out.= "Referer: http://school.jxllt.com/teacher/perwritesms_second.asp\r\n";
        $out.= "Accept-Language: zh-cn\r\n";
        $out.= "Content-Type: application/x-www-form-urlencoded\r\n";
        $out.= "Accept-Encoding: gzip, deflate\r\n";
        $out.= "User-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Maxthon; .NET CLR 1.1.4322)\r\n";
        $out.= "Host: school.jxllt.com\r\n";
        $out.= "Content-Length: $len\r\n";
        $out.= "Connection: Close\r\n";
        $out.= "Cache-Control: no-cache\r\n";
        $out.= "Cookie: $cookie\r\n";
        $out.= "\r\n";
        $out.= $postmsg;

        fwrite($fp, $out);
        while (!feof($fp)) {
            $con.= fgets($fp, 1024);
        }
        fclose($fp);
        return $con;
    }
}//end send sms

//
function striptags($con)
{
	$con = strip_tags($con);
	$con = str_replace("\r",'',$con);
	$con = str_replace("\n",'',$con);
	$con = str_replace("\t",'',$con);
	$con = str_replace("&nbsp;",'',$con);
	$con = trim($con);
	return $con;
}



?>
