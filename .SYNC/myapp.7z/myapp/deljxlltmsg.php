<?php
ini_set('include_path', dirname(__FILE__) . '/libs/PEAR');
include_once('libs/common.php');
include_once('HTTP/myClient.php');
include_once('libs/sms.php');

//login
$http = new myHttpClient();
$posturl = "http://school.jxllt.com/login_action.asp";
$post = array(
	'txt_userid' => '420064',
	'txt_passwd' => '12345678',
	'rad_usertype' => 'B'
);
$http->post($posturl,$post);
//pp($http->currentResponse(),1);



////////////////ɾ��������//////////////////
$recvsmsbox = $http->getHTML('http://school.jxllt.com/teacher/sendsmsbox.asp?menuid=19&mname=������');
preg_match_all('/messageid=(\d+)/', $recvsmsbox, $arr);
$msgids = array_unique($arr[1]);
//pp($msgids);
!empty($msgids) and delsendmsg($msgids);
//������
function delsendmsg($msgids)
{
    if(!$cookie=loginsms()) return false;
    $fp = fsockopen("school.jxllt.com", 80, $errno, $errstr, 30);
    if (!$fp) {
        return false;
    } else {
        foreach ($msgids as $id)
        {
			$postmsg .= "checkmsg=$id&";
        }
        $postmsg .= 'chkall_text=on&delmsg=%C9%BE%B3%FD&msgtype=';
        $len = strlen($postmsg);

        $out = "POST /teacher/del_sendmsgbox.asp HTTP/1.1\r\n";
        $out.= "Accept: image/gif, image/x-xbitmap, image/jpeg, image/pjpeg, application/x-shockwave-flash, application/msword, application/vnd.ms-excel, application/vnd.ms-powerpoint, */*\r\n";
        $out.= "Referer: http://school.jxllt.com/teacher/perwritesms_second.asp\r\n";
        $out.= "Accept-Language: zh-cn\r\n";
        $out.= "Content-Type: application/x-www-form-urlencoded\r\n";
        $out.= "Accept-Encoding: gzip, deflate\r\n";
        $out.= "User-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Maxthon; .NET CLR 1.1.4322)\r\n";
        $out.= "Host: school.jxllt.com\r\n";
        $out.= "Content-Length: $len\r\n";
        $out.= "Connection: Close\r\n";
        $out.= "Cache-Control: no-cache\r\n";
        $out.= "Cookie: $cookie\r\n";
        $out.= "\r\n";
        $out.= $postmsg;

        fwrite($fp, $out);
        fclose($fp);
    }
}

////////////////////ɾ���ռ���///////////////////////
$recvsmsbox = $http->getHTML('http://school.jxllt.com/teacher/recvsmsbox.asp?menuid=18&mname=�ռ���');
preg_match_all('/messageid=(\d+)/', $recvsmsbox, $arr);
$msgids = array_unique($arr[1]);
//pp($msgids);
!empty($msgids) and delrecvmsg($msgids);
//�ռ���
function delrecvmsg($msgids)
{
    if(!$cookie=loginsms()) return false;
    $fp = fsockopen("school.jxllt.com", 80, $errno, $errstr, 30);
    if (!$fp) {
        return false;
    } else {
        foreach ($msgids as $id)
        {
			$postmsg .= "checkmsg=$id&";
        }
        $postmsg .= 'chkall_text=on&delmsg=%C9%BE%B3%FD&msgtype=&hid_pageno=1';
        $len = strlen($postmsg);

        $out = "POST /teacher/del_recvsmsbox.asp HTTP/1.1\r\n";
        $out.= "Accept: image/gif, image/x-xbitmap, image/jpeg, image/pjpeg, application/x-shockwave-flash, application/msword, application/vnd.ms-excel, application/vnd.ms-powerpoint, */*\r\n";
        $out.= "Referer: http://school.jxllt.com/teacher/perwritesms_second.asp\r\n";
        $out.= "Accept-Language: zh-cn\r\n";
        $out.= "Content-Type: application/x-www-form-urlencoded\r\n";
        $out.= "Accept-Encoding: gzip, deflate\r\n";
        $out.= "User-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Maxthon; .NET CLR 1.1.4322)\r\n";
        $out.= "Host: school.jxllt.com\r\n";
        $out.= "Content-Length: $len\r\n";
        $out.= "Connection: Close\r\n";
        $out.= "Cache-Control: no-cache\r\n";
        $out.= "Cookie: $cookie\r\n";
        $out.= "\r\n";
        $out.= $postmsg;

        fwrite($fp, $out);
        fclose($fp);
    }
}//end send sms


////////////////////ɾ���ռ������վ///////////////////////
$recvsmsbox = $http->getHTML('http://school.jxllt.com/teacher/smsrecycle.asp');
//pp($recvsmsbox);
preg_match_all('/messageid=(\d+)/', $recvsmsbox, $arr);
$msgids = array_unique($arr[1]);
//pp($msgids);
!empty($msgids) and delrecycle($msgids);
//�ռ���
function delrecycle($msgids)
{
    if(!$cookie=loginsms()) return false;
    $fp = fsockopen("school.jxllt.com", 80, $errno, $errstr, 30);
    if (!$fp) {
        return false;
    } else {
        foreach ($msgids as $id)
        {
			$postmsg .= "checkmsg=$id&";
        }
        $postmsg .= 'chkall_text=on&action=%B3%B9%B5%D7%C9%BE%B3%FD&msgtype=';
        $len = strlen($postmsg);

        $out = "POST /teacher/smsrecycle.asp HTTP/1.1\r\n";
        $out.= "Accept: image/gif, image/x-xbitmap, image/jpeg, image/pjpeg, application/x-shockwave-flash, application/msword, application/vnd.ms-excel, application/vnd.ms-powerpoint, */*\r\n";
        $out.= "Referer: http://school.jxllt.com/teacher/perwritesms_second.asp\r\n";
        $out.= "Accept-Language: zh-cn\r\n";
        $out.= "Content-Type: application/x-www-form-urlencoded\r\n";
        $out.= "Accept-Encoding: gzip, deflate\r\n";
        $out.= "User-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Maxthon; .NET CLR 1.1.4322)\r\n";
        $out.= "Host: school.jxllt.com\r\n";
        $out.= "Content-Length: $len\r\n";
        $out.= "Connection: Close\r\n";
        $out.= "Cache-Control: no-cache\r\n";
        $out.= "Cookie: $cookie\r\n";
        $out.= "\r\n";
        $out.= $postmsg;

        fwrite($fp, $out);
        fclose($fp);
    }
}//end send sms


////////////////////ɾ���ռ������վ///////////////////////
$recvsmsbox = $http->getHTML('http://school.jxllt.com/teacher/smsrecyclesend.asp');
//pp($recvsmsbox);
preg_match_all('/msgid=(\d+)/', $recvsmsbox, $arr);
$msgids = array_unique($arr[1]);
//pp($msgids);
!empty($msgids) and delsendrecycle($msgids);
//�ռ���
function delsendrecycle($msgids)
{
    if(!$cookie=loginsms()) return false;
    $fp = fsockopen("school.jxllt.com", 80, $errno, $errstr, 30);
    if (!$fp) {
        return false;
    } else {
        foreach ($msgids as $id)
        {
			$postmsg .= "checkmsg=$id&";
        }
        $postmsg .= 'chkall_text=on&action=%B3%B9%B5%D7%C9%BE%B3%FD&msgtype=';
        $len = strlen($postmsg);

        $out = "POST /teacher/smsrecyclesend.asp HTTP/1.1\r\n";
        $out.= "Accept: image/gif, image/x-xbitmap, image/jpeg, image/pjpeg, application/x-shockwave-flash, application/msword, application/vnd.ms-excel, application/vnd.ms-powerpoint, */*\r\n";
        $out.= "Referer: http://school.jxllt.com/teacher/perwritesms_second.asp\r\n";
        $out.= "Accept-Language: zh-cn\r\n";
        $out.= "Content-Type: application/x-www-form-urlencoded\r\n";
        $out.= "Accept-Encoding: gzip, deflate\r\n";
        $out.= "User-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Maxthon; .NET CLR 1.1.4322)\r\n";
        $out.= "Host: school.jxllt.com\r\n";
        $out.= "Content-Length: $len\r\n";
        $out.= "Connection: Close\r\n";
        $out.= "Cache-Control: no-cache\r\n";
        $out.= "Cookie: $cookie\r\n";
        $out.= "\r\n";
        $out.= $postmsg;

        fwrite($fp, $out);
        fclose($fp);
    }
}//end send sms


echo 'ok';

$url = $_SERVER['PHP_SELF'];
echo "<script>location='$url';</script>";
