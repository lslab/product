<?php
set_time_limit(0);
define('ROOT', dirname(__FILE__));

ini_set('include_path', ROOT . '/libs/PEAR');
include_once(ROOT . '/libs/common.php');
include_once(ROOT . '/libs/sms.php');
include_once('HTTP/myClient.php');

$http = new myHttpClient();

$con = $http->getHTML('http://php.weather.sina.com.cn/search.php?city=��ɽ&dpc=1');

preg_match_all('/<div class="City_Data">.*?<\/h3>(.*?)<div class="Weather_SM">/is',$con,$arDate);
//pp($arDate[1],1);
//pp($arWea[1],1);

for ($i=0; $i<count($arDate[1]); $i++)
{
	$weather.= $arDate[1][$i].' '.$arWea[1][$i].' ';
}

//ɾ������
//$weather = preg_replace('/<div class="Weather_W">.*?<\/div>/is','',$weather);

//$weather = striptags($weather);
//$weather = preg_replace('/\d{2,4}��/','',$weather);
//$weather = preg_replace('/\d{4}-/','',$weather);
//$weather = preg_replace('/\d{2}-/','',$weather);
//$weather = str_replace(array(' ','��','����','����һ','���ڶ�','������','������','������','������','������'),'',$weather);
//$weather = preg_replace('/\d{1,2}��/'," ",$weather);


pp($weather);


//sendsms('051251309080',$weather);
sendsms('13306269569',$weather);


?>
