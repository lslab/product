<?php
//reply('http://www.im286.com',
//	'post.php?action=reply&fid=41&tid=3434193&extra=page%3D1&replysubmit=yes&infloat=yes&handlekey=fastpost',
//	'abc'
//);

function reply($baseurl,$topicurl,$reply_con) {
	global $http;
	
	if (!preg_match('|/$|i', $baseurl)) {
		$baseurl .= '/';
	}
	
	//�ж��Ƿ��Ѿ���½

		//formhash
		$html = $http->getHtml($baseurl . 'logging.php?action=login');
		preg_match('/name="formhash"\s+value="(.*?)"/', $html, $ar);
		$userformhash = $ar[1];
		//user login
		$userlogin = array(
			'formhash' => $userformhash,
			'cookietime' => '2592000',
			'loginfield' => 'username',
			'username' => '�����ںδ�',
			'password' => 'icando',
			'userlogin' => 'true',
		);
		$userloginurl = $baseurl . 'logging.php?action=login&loginsubmit=yes&inajax=1';
		$http->post($userloginurl, $userlogin);
		//$response = $http->currentResponse();	echo '<pre>';print_r($response);die;///////////////////////

	//get loginned formhash
	$html = $http->getHtml($baseurl.'memcp.php');
	preg_match('/formhash=([a-z0-9]+)/i', $html, $ar);
	$userformhash = $ar[1];
	//pp($userformhash,1);/////////////////////
	//user post
	$html2=$http->getHtml($topicurl);
	preg_match('/action="(post\.php.*?)"/',$html2,$ar);
	$posturl=$ar[1];
	$posturl=str_replace('&amp;','&',$posturl);
	$userposturl = $baseurl . $posturl;
	//pp($userposturl,1);///////////////////
	$userpost = array(
		'formhash'	=>	$userformhash,
		'subject'	=>	'PHPש��',
		'usesig'	=>	'1',
		'message'	=>	$reply_con,
	);
	//pp($userpost,1);///////////////////////////
	$http->post($userposturl, $userpost);
	$rep=$http->currentResponse();
	file_put_contents(dirname(__FILE__).'/reply.htm', print_r($rep,true));
}