<?php
//error_reporting(E_ALL);
//header("Cache-Control: no-cache");

ini_set('include_path','e:/wwwroot/PEAR');

require_once "HTTP/Request.php";

$req = new HTTP_Request("http://www.im286.com/");
$req->setMethon = HTTP_REQUEST_METHOD_POST;

$response = $req->sendRequest();

if (PEAR::isError($response)) {
    echo $response->getMessage();
} else {
    print_r($req->getResponseCookies());
}


##################################################
die;

include_once('HTTP/Client.php');

//login
$http = new HTTP_Client();
$posturl = "http://school.jxllt.com/login_action.asp";
$post = array(
	'txt_userid' => '420064',
	'txt_passwd' => '51309080',
	'rad_usertype' => 'B'
);
$http->post($posturl,$post);

//send
$posturl = "http://school.jxllt.com/teacher/perwritesms_action.asp";
$post = array(
	'tmobile' => '051251309080',
	'grouptype' => 'teacher',
	'groupmember' => '051251309080',
	'txta_memo' => "hello world"
);
$http->post($posturl,$post);

print_r($http->currentResponse());

