<?php
error_reporting(E_ALL &~ E_NOTICE);
ob_implicit_flush();
//@set_time_limit(300);
//session_start();
//header('Content-Type: text/html; charset=utf-8');

define('ROOT',dirname(__FILE__));

include_once(ROOT.'/config.php');

set_include_path(ROOT.'/PEAR');
include_once('HTTP/myClient.php');

$http = new myHttpClient();
$httpHeader = array(
//    'Referer' => 'http://www.538538.com/',
    'Accept-Language' => 'zh-cn',
    'User-Agent' => 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)',
    //'Accept-Encoding'	=>	'gzip, deflate',
);
$http->setDefaultHeader($httpHeader);
$http->setMaxRedirects(0);
$http->autoReferer=false;

include(ROOT.'/cache.class.php');
$options=array(
	'cacheDir'	=>	ROOT.'/cache',
	'lifeTime'	=>	3600*$cachetime,
//	'dirLevels'	=>	$cacheDirLevels,
);
$cache=new Cache($options);


////////////////////////////////////
function pp($v,$d=null)
{
	echo '<pre>';
	print_r($v);
	echo '</pre>';
	$d ? die : null;
}
