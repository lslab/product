<?php
include_once(dirname(__FILE__).'/common.inc.php');

$domain=$http_host=strtolower($_SERVER['HTTP_HOST']);
$request_url=$_SERVER['REQUEST_URI'];
$url='http://'.$domain.$request_url;
$url=replaceURL($url,'unreplace');


//pp($url,1);

//ʵʱ���鲻ʹ�û���
//if (!preg_match('/(\.js|\.css|\.jpg|\.jpeg|\.gif|\.png)$/i',$url)) {
//	$cachetime=0;
//}

if (!empty($_POST)) {
	$http->post($url,$_POST);
	$html=$http->body();
} else {
	if ($cachetime>0) {
		if (!$html=$cache->get($url)) {
			$html=$http->html($url);
			$cache->save($html);
		}
	} else {
		$html=$http->html($url);
	}		
}

if (strpos($html,'common.js')!==false) { file_put_contents('g:/a.txt',$url); }


$html=common_replace($html);
$html=con_replace($html);


echo $html;


////////////////////////////
function common_replace($html) {
	global $domain;
	
	#######ͨ��#######
	$html=replaceURL($html);
	
	########replace.txt######
	$file=file(ROOT.'/replace.txt');
	foreach ($file as $line) {
		list($s,$r)=explode("\t",$line,2);
		$html=str_replace($s,$r,$html);
	}
	return $html;
}


//����ҳ��
function con_replace($html) {
	global $domain;
	include(ROOT.'/config.php');///////////////////////////////////////////////

	////////////������//////////
	$header=file_get_contents(ROOT.'/html/header.html');
	$index_middle_ad_1=file_get_contents(ROOT.'/html/index_middle_ad_1.html');
//	$index_middle_ad_2=file_get_contents(ROOT.'/html/index_middle_ad_2.html');
	$page_middle_ad_1=file_get_contents(ROOT.'/html/page_middle_ad_1.html');
	$page_middle_ad_2=file_get_contents(ROOT.'/html/page_middle_ad_2.html');
	$page_right_ad_1=file_get_contents(ROOT.'/html/page_right_ad_1.html');

	$footer=file_get_contents(ROOT.'/html/footer.html');

	//��ҳ���б�ҳ ����
	$html=preg_replace('`<table cellSpacing=0 cellPadding=0 width=986 border=0>.*?</table>.*?</table>.*?</table>`is',$header,$html,1);
	//����ҳ ����
	$html=preg_replace('`<table width=986 border=0 align="center" cellPadding=0 cellSpacing=0>.*?</table>.*?</table>.*?</table>`is',$header,$html,1);
	//��ҳ�м���һ
	$html=preg_replace('`<table width="986" height="100" border="0" cellpadding="0" cellspacing="0">.*?</table>`is',$index_middle_ad_1,$html);
	//��ҳ�м����
//	$html=preg_replace('`<table cellSpacing=0 cellPadding=0 width=986 border=0>\s+<tr>\s+<td height=8>.*?</table>`is',$index_middle_ad_2,$html,1);
	
	//����ҳ���һ ��������
	$html=preg_replace('~<table cellSpacing=0 cellPadding=0 width="100%" border=0>\s+<tr>\s+<td align=middle height=80>.*?</table>~is',$page_middle_ad_1,$html);;
	//����ҳ���� ͼƬ����
	$html=preg_replace('~<table width="100%" height="20" border=0 cellPadding=8 cellSpacing=0 bgcolor="#CCCCCC">.*?</table>~is',$page_middle_ad_2,$html);;
	//����ҳ��� ��վ�Ƽ�
	$html=preg_replace('~<table height=64 cellSpacing=0 cellPadding=0 width="100%" border=0>.*?</table>~is',$page_right_ad_1,$html);;
	//����ҳ�ײ���� ͼƬ���������
	$html=preg_replace('~<td height="84" vAlign=top bgColor=#ffffff><table width="100%" border=0 cellPadding=10 cellSpacing=1 bgcolor="#CCCCCC">.*?</td>~is',"<td>$page_middle_ad_3</td>",$html);;

	//ɾ������ҳ�ײ����һ
	$html=preg_replace('|<table width="986" height="40" border=0 align="center" cellPadding=8 cellSpacing=1 bgColor=#cccccc>.*?</table>|is','',$html);
	
	//��ҳ�ײ�
	$html=preg_replace('|<table height=63 cellSpacing=1 cellPadding=0 width="100%" bgColor=#cccccc border=0>.*?</table>|is',$footer,$html);
	$html=preg_replace('|<table cellSpacing=2 width="100%">.*?</body>|is','</body>',$html);
	//�б�ҳ�ײ�
	$html=preg_replace('|<table cellSpacing=0 cellPadding=16 width=100% border=0>.*?</table>|is',$footer,$html);

	
	
	
	return $html;
}





///////////////////////////////
/**
 * �滻��ַ
 *
 * @param unknown_type $url
 * @param unknown_type $mode	replace/unreplace
 */
function replaceURL($url,$mode='replace')
{
	global $domain;
	$ps=array(
		'wvw.rtysuu.com'	=>	$domain.'/wvwrtysuucom',
		'www.rtysuu.com'	=>	$domain,	//���Ҫ������滻
	);
	foreach ($ps as $key=>$val) {
		if ($mode=='replace') {
			$url=str_ireplace($key,$val,$url);
		} else {
			$url=str_ireplace($val,$key,$url);
		}
	}
	
	return $url;
}//replaceURL