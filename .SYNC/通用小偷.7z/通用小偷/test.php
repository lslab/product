<?php
echo mb_detect_encoding('中国');
echo "\nok";