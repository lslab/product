<?php
sae_set_display_errors(true);

include_once('config.php');
include_once('httpclient.class.php');
include_once('functions.php');
include_once('db.class.php');
include_once('jxllt.php');

$http = new HttpClient('2m2jnjyo5o','h40h1lyhx1h1kk1jl4k0415mj4i5jj2lzx3l2ym2');


$con = $http->get("http://www.im286.com/forumdisplay.php?fid=41");

preg_match_all('/<span id="thread_\d+"><a href="thread-(\d+)-\d+-\d+\.html">(.*?)<\/a><\/span>/i',$con,$artid);
for($i=0;$i<count($artid[0]);$i++) {
	$arts[$artid[1][$i]]=$artid[2][$i];
}
pp($arts);
$rs = $db->findAll('tasks', null, "site='admin5'");
$oldtids = array();
foreach ((array)$rs as $v)
{
	$oldtids[] = $v['id'];
}

foreach ($arts as $tid=>$title) {
	if (!in_array($tid, $oldtids)) {
		$topicurl = "http://www.im286.com/viewthread.php?tid={$tid}";
		$con = $http->get($topicurl);
		preg_match('/<title>(.*?) - /', $con, $arTitle);
		pp($arTitle);
		$title=$arTitle[1];
		$title=strip_tags($title);
		$title=trim($title);

		$isSend=true;
		foreach ($limitKey as $limit) {
			if (strpos(strtolower($title),strtolower($limit))!==false) {
        		$isSend=false;
        	}
        }

		if($isSend) {sendMsg('[��]'.$title);}
		
		$db->create('tasks', array('id' => $tid, 'site' => 'admin5'));
        
	}
}


?>

ok
