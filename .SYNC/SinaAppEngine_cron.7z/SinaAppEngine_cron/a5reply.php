<?php
sae_set_display_errors(true);

include_once('httpclient.class.php');
include_once('functions.php');

//echo admin5_reply('1975902','aa������ ����ϵ�� QQ 107710715');

function admin5_reply($tid,$replyContent) {
	$f = new HttpClient('2m2jnjyo5o','h40h1lyhx1h1kk1jl4k0415mj4i5jj2lzx3l2ym2');

	//��½
	$html=$f->get('http://bbs.admin5.com/logging.php?action=login');
	$formhash=regMatch($html,'/name="formhash" value="([a-z0-9]+)"/i');
	$userlogin = array(
		'formhash' => $formhash,
		'cookietime' => '2592000',
		'loginfield' => 'username',
		'username' => '�����ںδ�',
		'password' => 'icando',
		'userlogin' => 'true',
	);
	$userloginurl = 'http://bbs.admin5.com/logging.php?action=login&loginsubmit=yes&inajax=1';
	$f->post($userloginurl,$userlogin);

	//�ظ�
	$html=$f->get("http://bbs.admin5.com/viewthread.php?tid=$tid");
	$formhash=regMatch($html,'/formhash=([a-z0-9]+)/i');

echo	$userposturl = "http://bbs.admin5.com/post.php?action=reply&fid=447&tid=$tid&extra=&replysubmit=yes&infloat=yes&handlekey=fastpost";
	//pp($userposturl);///////////////////
	$userpost = array(
		'formhash'	=>	$formhash,
		'subject'	=>	'PHPש��',
		'usesig'	=>	'1',
		'message'	=>	$replyContent,
	);
	
	pp($userpost);///////////////////////////
	return $f->post($userposturl, $userpost);
	
}//function