<?php
sae_set_display_errors(true);

include_once('httpclient.class.php');
include_once('functions.php');

function sendMsg($msg) {
	$http = new HttpClient('2m2jnjyo5o','h40h1lyhx1h1kk1jl4k0415mj4i5jj2lzx3l2ym2');

	//��½
	$posturl = "http://school.jxllt.com/login_action.asp";
	$post = array(
	    'txt_userid' => '420064',
	    'txt_passwd' => '12345678',
	    'rad_usertype' => 'B'
	);
	$http->post($posturl,$post);

	//send
	$posturl = "http://school.jxllt.com/teacher/schnotice_action.asp";
	$data = array();
	$data['sel_group'] = '11524';
	$data['rcvlist'] = '420064|�˽�';
	$data['txta_memo'] = $msg;
	$data['remain2'] = '20';
	$data['remain1'] = '90';
	$data['msgtime'] = '';
	$data['SEND'] = '����';
	echo $http->post($posturl,$data);
	
}//function