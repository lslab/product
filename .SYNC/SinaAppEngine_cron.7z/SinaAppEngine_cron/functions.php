<?php
//////////////////////////////
function regMatch($str, $regStr, $striphtml=true)
{
	if (preg_match($regStr, $str, $result)) {
		if (isset($result[1])) {
			$r= trim($result[1]);
		} else {
			$r= trim($result[0]);
		}
		$rr= $striphtml ? strip_tags($r) : $r;
		return trim($r);
	} else {
		return null;
	}
}

function pp($v,$d=null)
{
	echo '<pre>';
	print_r($v);
	echo '</pre>';
	$d ? die : null;
}
