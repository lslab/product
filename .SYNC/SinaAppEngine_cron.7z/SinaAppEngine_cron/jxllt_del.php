<?php
sae_set_display_errors(true);

include_once('config.php');
include_once('httpclient.class.php');
include_once('functions.php');

$http = new HttpClient('2m2jnjyo5o','h40h1lyhx1h1kk1jl4k0415mj4i5jj2lzx3l2ym2');

//��½
$posturl = "http://school.jxllt.com/login_action.asp";
$post = array(
    'txt_userid' => '420064',
    'txt_passwd' => '12345678',
    'rad_usertype' => 'B'
);
$http->post($posturl,$post);

////////////////ɾ��������//////////////////
$recvsmsbox = $http->get('http://school.jxllt.com/teacher/sendsmsbox.asp?menuid=19&mname=������');
preg_match_all('/messageid=(\d+)/', $recvsmsbox, $arr);
$msgids = array_unique($arr[1]);
foreach($msgids as $id) {
	$data=array(
		'checkmsg'	=>	$id,
		'delmsg'	=>	'ɾ��',
		'msgtype'	=>	''
	);
	$http->post('http://school.jxllt.com/teacher/del_sendmsgbox.asp',$data);
}
////////////////ɾ���ռ���//////////////////
$recvsmsbox = $http->get('http://school.jxllt.com/teacher/recvsmsbox.asp?menuid=18&mname=�ռ���');
preg_match_all('/messageid=(\d+)/', $recvsmsbox, $arr);
$msgids = array_unique($arr[1]);
foreach($msgids as $id) {
	$data=array(
		'checkmsg'	=>	$id,
		'delmsg'	=>	'ɾ��',
		'msgtype'	=>	'',
		'hid_pageno'	=>	'1'
	);
	$http->post('http://school.jxllt.com/teacher/del_recvsmsbox.asp',$data);
}
////////////////ɾ���ջ�վ//////////////////
$recvsmsbox = $http->get('http://school.jxllt.com/teacher/smsrecycle.asp?menuid=20&mname=����վ');
preg_match_all('/messageid=(\d+)/', $recvsmsbox, $arr);
$msgids = array_unique($arr[1]);
foreach($msgids as $id) {
	$data=array(
		'checkmsg'	=>	$id,
		'action'	=>	'����ɾ��',
		'msgtype'	=>	''
	);
	$http->post('http://school.jxllt.com/teacher/smsrecycle.asp?menuid=20&mname=����վ',$data);
}


echo 'ok';

$url = $_SERVER['PHP_SELF'];
echo "<script>location='$url';</script>";