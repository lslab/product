<?php
class HttpClient extends SaeFetchurl {
	private $_cookies=array();
	
	public function get($url) {
		$this->_setCookies();
		$result = $this->fetch($url);
		$this->_cookies=$this->responseCookies();
		
		return $result;
	}
	
	public function post($url,$data) {
		$this->_setCookies();
		$this->setMethod("post");
		$this->setPostData($data);
		$result = $this->fetch($url);
		$this->_cookies=$this->responseCookies();

		return $result;
	}
	
	private function _setCookies() {
		foreach((array)$this->_cookies as $c) {
			foreach((array)$c as $key=>$val) {
				$this->setCookie($key,$val);
			}
		}
	}
}//class